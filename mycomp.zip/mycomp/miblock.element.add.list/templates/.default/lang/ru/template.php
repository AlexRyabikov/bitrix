<?
$MESS ['IBLOCK_ADD_LIST_TITLE'] = "Города:";
$MESS ['IBLOCK_ADD_LIST_EMPTY'] = "Вы не добавляли никаких городов";
$MESS ['IBLOCK_ADD_LIST_EDIT'] = "редактировать";
$MESS ['IBLOCK_ADD_LIST_DELETE'] = "удалить";
$MESS ['IBLOCK_ADD_LIST_DELETE_CONFIRM'] = "Вы действительно хотите удалить город #ELEMENT_NAME#?";
$MESS ['IBLOCK_ADD_LINK_TITLE'] = "Добавить город";
$MESS ['IBLOCK_LIST_CANT_ADD_MORE'] = "Вы не можете добавлять новые города";
?>