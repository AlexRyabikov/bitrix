<?
$MESS ['IBLOCK_ELEMENT_ADD_LIST_NAME'] = "Список своих элементов";
$MESS ['IBLOCK_ELEMENT_ADD_LIST_DESCRIPTION'] = "Список своих элементов";
$MESS ['T_IBLOCK_DESC_ELEMENT_ADD'] = "Добавление элементов";
?>