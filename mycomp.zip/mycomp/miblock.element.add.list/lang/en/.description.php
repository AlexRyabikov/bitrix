<?
$MESS ['IBLOCK_ELEMENT_ADD_LIST_NAME'] = "Personal elements list";
$MESS ['IBLOCK_ELEMENT_ADD_LIST_DESCRIPTION'] = "Personal elements list";
$MESS ['T_IBLOCK_DESC_ELEMENT_ADD'] = "Add elements";
?>