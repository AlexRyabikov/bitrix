<?
$MESS ['IBLOCK_ELEMENT_ADD_NAME'] = "Add elements to information block";
$MESS ['IBLOCK_ELEMENT_ADD_DESCRIPTION'] = "Add elements to information block";
$MESS ['T_IBLOCK_DESC_ELEMENT_ADD'] = "Add elements";
?>
