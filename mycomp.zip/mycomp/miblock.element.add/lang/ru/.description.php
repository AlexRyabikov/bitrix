<?
$MESS ['IBLOCK_ELEMENT_ADD_NAME'] = "Добавление элементов инфоблока";
$MESS ['IBLOCK_ELEMENT_ADD_DESCRIPTION'] = "Добавление элементов инфоблока";
$MESS ['T_IBLOCK_DESC_ELEMENT_ADD'] = "Добавление элементов";
?>