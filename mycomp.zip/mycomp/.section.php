<?
$sSectionName="MyComp";
?>